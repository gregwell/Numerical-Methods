#include "pch.h"
#include <iostream>
#include "LagrangeInterpolation.h"
#include <fstream>

using namespace std;

int main()
{

	Lagrange interp;
	interp.interpolation();


	return 0;

}
