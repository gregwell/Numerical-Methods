﻿#include "pch.h"
#include <iostream>
#include "NewtonInterpolation.h"
#include <fstream>

using namespace std;

int main()
{

	Newton interp;
	interp.interpolation();



	return 0;

}
