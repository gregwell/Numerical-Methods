﻿#include "pch.h"
#include <iostream>
#include "GaussElimination.h"
#include <fstream>

using namespace std;

int main()
{


	Gauss test;
	test.gaussElimination();


	return 0;

}
