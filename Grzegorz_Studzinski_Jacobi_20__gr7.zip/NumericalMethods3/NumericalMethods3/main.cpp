﻿#include "pch.h"
#include <iostream>
#include "Jacobi.h"
#include <fstream>
#include <iomanip>
#include <math.h>

using namespace std;

int main()
{


	Jacobi test;
	test.Calculate();


	return 0;

}

